// Grab the Dependency for ther server
const express = require('express');
const app = express();
const port = process.env.PORT || 8000;
const expressLayouts = require('express-ejs-layouts');
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
var spawn = require("child_process").spawnSync;

//Confiure the application 
app.use(express.static('./assets'))
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(expressLayouts);

app.set('layout extractStyles', true);
app.set('layout extractScripts', true);

app.use('/', require('./routes/'));

//Start the Server 
app.listen(process.env.PORT || 8000,(err) =>{
    if(err){
        console.log(`Error in running -->: ${err}`);
    }
    console.log(`Server is Running on port${port}`);
})
