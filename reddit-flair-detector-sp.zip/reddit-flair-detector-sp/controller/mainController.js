

module.exports = {
    showHome: (req,res) => {
        // res.send('This is working fine :)');
        return res.render('home', {
            data_list: null
        })
    },
    fetch: (req,res) =>{
        let url = req.body.urlValue;
        console.log(url);
        
        var spawn = require("child_process").spawn;
        var process = spawn('python',["./sample.py", url] );
        // console.log(process.stdout);
        // process.stdout.on('data', (data) => console.log(data));
        process.stdout.on("data", data => {
            console.log(`process stdout:\n${data.toString()}`);
            var output = data.toString();
            return res.render('home', {
                data_list: output
            })
          });
  },
  showStatistics: (req,res) =>{
    res.render('statistics');
  }
};