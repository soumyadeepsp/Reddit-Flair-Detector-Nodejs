import sys 

print("First name: " + sys.argv[1]) 
# print("Last name: " + sys.argv[2]) 