const express = require('express');
const router = express.Router();

const homeController = require('../controller/mainController');

module.exports = router;
router.get('/', homeController.showHome);
router.post('/register', homeController.fetch);
router.get('/statistics', homeController.showStatistics);

